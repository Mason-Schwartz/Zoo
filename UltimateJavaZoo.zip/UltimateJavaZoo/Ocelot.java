
/**
 * The Ocelot is an Animal.
 *
 * @author Christopher Henggeler at RIT
 * @version 7/26/17
 */
public class Ocelot extends Animal implements Walking, Swimming
{
    // Fields
    private double lengthInFeet;
    private double weightInPounds;
    private String furColor;

    /**
     * Default Constructor for Ocelot
     */
    public Ocelot(){
        super("Laura the Ocelot", "Lives in the jungle");
        lengthInFeet = 4.75;
        weightInPounds = 40;
        furColor = "tawny";
    }

    /**
     * Constructor for Ocelot
     * 
     * @param name the name of the animal
     * @param desc the description of the animal
     * @param length the length of the Ocelot in feet
     * @param weight the weight of the Ocelot in pounds
     * @param fur the color of the Ocelot 
     */
    public Ocelot(String name, String desc, double length, double weight, String fur){
        super(name, desc);
        lengthInFeet = length;
        weightInPounds = weight;
        furColor = fur;
    }

    /**
     * Constructor for objects of class Ocelot
     * 
     * @param name the name of the Ocelot
     * @param desc the description of where the Ocelot lives
     */
    public Ocelot(String name, String desc){
        super(name, desc);
        lengthInFeet = 4.75;
        weightInPounds = 40;
        furColor = "tawny";
    }

    /**
     * Accessor for lengthInFeet
     *
     * @return    the length of the Oceleot in feet
     */
    public double getLength()
    {
        return lengthInFeet;
    }

    /**
     * Mutator for lengthInFeet
     *
     * @param  length  the length (in feet) of the Ocelot
     */
    public void setLength(double length)
    {
        lengthInFeet = length;
    }

    /**
     * Accessor for WeightInPounds
     *
     * @return    the weight of the Oceleot in pounds
     */
    public double getWeight()
    {
        return weightInPounds;
    }

    /**
     * Mutator for weightInPounds
     *
     * @param  length  the weight (in pounds) of the Ocelot
     */
    public void setWeight(double weight)
    {
        weightInPounds = weight;
    }

    /**
     * Accessor for furColor
     *
     * @return    the color of the Oceleot
     */
    public String getFurColor()
    {
        return furColor;
    }

    /**
     * Mutator for furColor
     *
     * @param  fur  the new color of the Ocelot (tawny, yellow, or brown-grayish) 
     */
    public void setFurColor(String fur)
    {
        furColor = fur;
    }

    /**
     * Override for Animal:eat()
     *
     * @returns a string stating what the Oceleot eats 
     */
    @Override
    public String eat(){
        return "Ocelots eat rodents, monkeys, tortoises, armadillos, rabbits, birds, lizards, fish, snakes…";
    }

    /**
     * Override for Animal:makeNoise()
     *
     * @returns a string emulating how the animal makes noise 
     */
    @Override
    public String makeNoise(){
        return "Yowwwwl";
    }

    /**
     * Override of Walking:walk()
     * 
     * @return    a string containing the walking behavior of the Oceleot
     */

    @Override 
    public String walk()
    {
        return "Ocelots may travel up to 7 miles per night while it searches for the food.";
    }

    /**
     * Override of Walking:swim()
     * 
     * @return    a string containing the swimming behavior of the Oceleot
     */

    @Override 
    public String swim()
    {
        return "Unlike other cat species, ocelots are not afraid of the water. They are excellent swimmers.";
    }

    /**
     * Override of toString method
     *
     * @return    the name and decription of the animal
     */
    public String toString()
    {
        return this.getClass().getName() + " " + super.toString() + " and is " + lengthInFeet + " feet long, \n weighs " + weightInPounds
        + " pounds, and its color is " + furColor;
    }

    
}
