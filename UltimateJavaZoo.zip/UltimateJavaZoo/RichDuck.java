
public class RichDuck extends Duck
{
    int money;
    Duck[] nephews = 
        {new Duck("Huey", "red"), new Duck("Dewey","blue"), new Duck("Louie", "green")};

    public RichDuck()
    {
        super("Scrooge the Rich Duck", "one rich duck");
        this.money = 1000000000;
    }

    @Override
    public String eat()
    {
        return "the rich duck eats pate";
    }

    @Override
    public String makeNoise()
    {
        return "DuckTales! Woohoo!";
    }

    @Override
    public String swim()
    {
        return "The duck dives into his money and swims around a bit.";
    }

    @Override
    public String fly()
    {
        return "The rich duck flies first class.";
    }

}
