public class NinjaAlligator extends Alligator
{
    private String ninja;

    public NinjaAlligator()
    {
        super("Leoangello the Ninja Alligator", "He has been well trained in the ways of the Ninja!");
        this.ninja = "deadly";
    }

    @Override
    public String makeNoise()
    {
        return "GATOR NINJA CHOP!!!";
    }

    @Override
    public String swim()
    {
        return "swims in beastlike NINJA fashion!";
    }
}