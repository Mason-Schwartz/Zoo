
public class SovietCircusBear extends Bear
{
    private String toy;

    /**
     * Constructor for objects of class SovietCircusBear
     */
    public SovietCircusBear()
    {
        super("Vlad the Soviet Circus Bear that has lived for a while",
            "It rides around on its tricycle.");
        this.toy = "tricycle";
    }

    @Override
    public String makeNoise()
    {
        return "the tricycle squeaks as the bear rides it.";
    }
}
