public class Dog extends Animal implements Walking, Swimming{

    private String coat;
    public Dog() {
        super("Sophie the Dog", "I'm a German Shepherd");
        this.coat = "Shiny";
    }

    public Dog(String name, String desc, String coat) {
        super(name, desc);

        this.coat = coat;
    }

    public String getCoat() {
        return this.coat;
    }

    public void setCoat(String coat) {
        this.coat = coat;
    }

    @Override
    public String eat() {
        return "I devour everything in my dish!";
    }

    @Override
    public String makeNoise() {
        return "Bark! Bark! Bark!!!";
    }

    @Override
    public String walk() {
        return "I start walking but I like to chase squirrels in the back yard! ";
    }

    @Override
    public String swim() {
        return "I only swim when I'm at the lake. It's nice to cool off in the hot sun.";
    }
    
    @Override
    public String smell() {
        return "The dog smells like dirt.";
    }

    @Override
    public String toString() {
        return  this.getClass().getName() + " " + super.toString() + "--" +this.coat;
    }
}
