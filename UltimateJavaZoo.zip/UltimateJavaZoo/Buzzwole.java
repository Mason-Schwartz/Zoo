public class Buzzwole extends Animal implements Walking, Swimming, Flying
{
    public Buzzwole()
    {
        super("Buzz the Buzzwole", "Buff Bug that will punch anything and anyone into oblivion. Bug-Fighting type that will wreck your day, kid");
    }

    @Override
    public String eat()
    {
        return "kkkKkKKKrEEEEE (Give me some beans, protein, and blood, human. Or I will punch you into the Ultra Space)";
    }

    @Override
    public String makeNoise()
    {
        return "kkKKKKKRrreEEEEEEEEHH";
    }

    @Override
    public String walk()
    {
        return "kKrkrkrkrrrreeeeEE (I pose as I walk. And I can kick your butt. I move extremely quickly from my B U F F N E S S";
    }

    @Override
    public String swim()
    {
        return "KkKKKkrEEE, KkKKKkrEEE, KkKKKkrEEE! (STROKE, STROKE, STROKE!)";
    }

    @Override
    public String fly()
    {
        return "*Flaps arms so fast and powerfully he defies the laws of nature and takes flight, using the power of S W O L E*";
    }
}
