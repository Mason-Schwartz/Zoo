
public class SilverFox extends Fox
{
    private String toy;

    public SilverFox()
    {
        super("Nigel the Silver Fox",
            "like a regular fox, only slyer");
        this.toy = "sheepskin jacket";
    }

    @Override
    public String makeNoise()
    {
        return "Well hellooo there. I'm awfully pleased to meet you.";
    }

    public String walking()
    {
        return "The silver fox rarely walks. Others come to him.";
    }
}
