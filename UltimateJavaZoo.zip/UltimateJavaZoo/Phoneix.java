
public class Phoneix extends Animal implements Walking, Flying
{
   public Phoneix()
   {
       this("Walt" , "Fireball is always playing in the background");
   }
   
   public Phoneix(String name, String description)
   {
     super(name, description);
   }
   @Override
   public String eat()
   {
       return "crackling fire";
   }
    
   public String makeNoise()
   {
       return "WHOOSH!";
   }
   
   public String walk()
   {
       return "hop...hop...hop";
   }
   
   public String fly()
   {
       return "flap...flap...flap";
   }
   
   public String smell()
   {
       return "The phoneix smells of ash and burnt wood.";
   }
}
