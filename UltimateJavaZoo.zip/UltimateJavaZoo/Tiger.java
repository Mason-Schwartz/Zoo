
/**
 * Tiger inherits from the abstract class animal (extends)
 * "is a" relationship (Tiger "is a" Animal)
 * Uses the walking interface (implements)
 */
public class Tiger extends Animal implements Walking
{
    //Default Constructor
    public Tiger()
    {
        // super gives access to parent class constructor. 
        super("Simba the Tiger" , "A popular Disney tiger"); 
    }

    //Constructor to take name and description. Accesses parents
    public Tiger(String name, String desc)
    {
        super(name, desc);  //access animal constructor 
    }

    @Override
    public String eat() 
    {
        return "The tiger loves to eat fresh meat. Do you have a steak for me?";
    }

    @Override
    public String makeNoise()
    {
        return "ROAAAR!!!";
    }

    @Override
    public String walk()
    {
        return "I stalk quietly with majestic agility";
    }
}
