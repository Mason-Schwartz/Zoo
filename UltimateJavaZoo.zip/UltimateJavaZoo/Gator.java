
public class Gator extends Animal implements Walking, Swimming
{
    //ad more functionality
    
    public Gator()
    {
        //calling parent constructor
        super ("Albert the Gator", "A friendly gator from Florida");
        
    }
    
    public Gator(String name, String desc)
    {
        super(name,desc);
    }
    
    @Override
    public String eat()
    {
        return "The Gator eats a poor baby croc";
               
    }
    @Override
    public String makeNoise()
    {
        return "Grrrr";
    }
    @Override
    public String walk()
    {
      return "With a slow pace...";  
    }
    @Override
    public String swim()
    {
      return "moving in water";  
    }
    
}
