public class NylanderiaFulva extends Animal implements Walking, Flying {
    public NylanderiaFulva(){
        super("Auntie Nylanderia Fulva", "The crazy ant with crazy powers");
    }

    @Override
    public String eat() {
        return "Any sweet or protein substances, including crabs";
    }

    @Override
    public String makeNoise() {
        return "Silence, like a acid spitting ninja";
    }

    @Override
    public String walk(){
        return "I move 200 meters a year.";
    }

    @Override
    public String fly(){
        return "I got wings! Prepare for the acid divebombs son.";
    }
}

