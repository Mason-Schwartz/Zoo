/**
 * Class to represent a Basilisk
 * 
 * @author Sheila Robles at UCCS
 * @version 6/20/2018
 */
public class Basilisk extends Animal implements Swimming
{
    public Basilisk(){
        super("Nagini the Basilisk", "I always hungry");
    }

    @Override
    public String eat(){
        return "I want to eat Dan";
    }

    @Override
    public String makeNoise(){
        return "Om nom nom";
    }

    public String swim(){
        return"He will slither through the water to scare people."; 
    }

}
