public class Snake extends Animal implements Swimming
{
    public Snake() 
    {
        super("Snidely the Snake", "your average snake");
    }

    public Snake(String name, String desc)
    {
        super(name, desc);
    }

    public String swim() {return "the snake swims the backstroke";}

    public String makeNoise()
    {
        return "hiss";
    }

    public String eat() 
    {
        return "the snake eats mice";
    }
}