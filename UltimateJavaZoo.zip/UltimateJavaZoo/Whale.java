
public class Whale extends WaterMammal implements Swimming
{
    public Whale() 
    {
        super("Whitworth the Whale", "Being large and ungainly, the whale is always self-conscious.");
    }

    public Whale(String name, String desc)
    {
        super(name, desc);
    }

    public String makeNoise()
    {
        return "Beluga beckons";
    }

    public String eat() 
    {
        return "the whale just opens its mouth and swims";
    }

    public String swim(){
        return "swims slowly and sedately";
    }
    
    public String smell() {
        return "The whale smells of blubber and salt water.";
    }
}
