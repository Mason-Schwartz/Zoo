
public class Vampire extends Bat
{
    private String power;

    public Vampire() 
    {
        super("Dracula the Vampire", "Vampires have special powers and aren't really bats.");
        this.power = "Some vampires are invisible.";
    }

    public String makeNoise()
    {
        return "The vampire says \"Look into my eyes....\" ";
    }

    public String eat() 
    {
        return "the vampire wants to drink you blood";
    }

    public String fly()
    {
        return "Vampires don't need wings to fly.";
    }
}
