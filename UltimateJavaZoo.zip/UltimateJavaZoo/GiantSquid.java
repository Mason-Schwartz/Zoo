
public class GiantSquid extends Animal implements Swimming
{
    public GiantSquid(){
        super("Larry the Giant Squid", "A Squid That is Giant");
    }

    @Override
    public String makeNoise(){
        return "Bloop ";
    }

    @Override
    public String eat(){
        return "Eats a fish ";
    }

    @Override
    public String swim(){
        return "Woosh ";
    }
}
