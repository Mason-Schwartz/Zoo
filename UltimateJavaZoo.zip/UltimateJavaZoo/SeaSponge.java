
public class SeaSponge extends Animal implements Swimming
{
    public SeaSponge() {
        super("Sampson the Sea Sponge", "Its a sponge in the sea.");
    }

    @Override
    public String eat() {
        return "PHOTOSYNTHESIS!";
    }

    @Override
    public String makeNoise() {
        return "Wild Sea Sponge remains completely silent...";
    }

    @Override
    public String swim() {
        return "Wild Sea Sponge does a splash...";
    }
}
