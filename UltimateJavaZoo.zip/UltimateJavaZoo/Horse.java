
public class Horse extends Animal implements Walking
{    
    public Horse()
    {
        super("Joe the Horse", "can be many colors");
    }

    public Horse(String name, String desc)
    {
        super(name, desc);
    }

    public String walk()
    {
        return "The horse gallops around the field.";
    }

    public String makeNoise()
    {
        return("neh...neh");
    }

    public String eat()
    {
        return("Hay, grass and oats.");
    }
}