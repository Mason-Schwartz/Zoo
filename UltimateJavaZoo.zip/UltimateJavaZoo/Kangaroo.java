/**
 * Class to represent a Capybara
 * 
 * @author Cory Cheever at UCCS
 * @version 6/20/2018
 */
public class Kangaroo extends Animal implements Walking, Swimming
{   
    /**
     * Constructor for objects of class Kangaroo
     */
    public Kangaroo()
    {
        super("Jack the Kangaroo", "They like to box.");
    }

    @Override
    public String eat() {
        return "They like to eat grass.";
    }

    @Override
    public String makeNoise() {
        return "They make a clucking sound and thomp their feet.";
    }

    @Override
    public String walk() {
        return "They hop around";
    }

    @Override
    public String swim() {
        return "They swim very ungraciously";
    }
}
