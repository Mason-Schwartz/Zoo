public class Badger extends Animal implements Walking,Swimming
{
    //Fields
    private String pack;

    public Badger(){
        super("Grumpy the Badger",  "I live in a hole");
        this.pack = "none";
    }   

    public Badger(String name, String desc, String pack){
        super(name, desc);
        this.pack = pack;
    }
    //setters & getters 
    public String getPack() {
        return this.pack;
    }

    public void setPack(String pack){
        this.pack = pack;
    }

    @Override
    public String eat(){
        return "I roam and I eat snakes.";
    }

    @Override
    public String makeNoise(){
        return "Chump..snizzly.";
    }

    @Override
    public String walk(){
        return "Lowly and wobbly meandering";
    }

    @Override 
    public String swim(){
        return "Slithering and wish-washing keeping nose above the water, but hates the H20";
    }
    
    @Override
    public String smell(){
        return "The badger smells of a forest and snakes.";
    }

    @Override
    public String toString(){
        //return super.toString() + " - " + this.pack; 
        return this.getClass().getName() + "  " + super.toString() + "-" + this.pack; 
    }

}

