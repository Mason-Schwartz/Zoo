// extends --- tells us that we will be using the Animal class 
public class Wildcat extends Animal implements Walking  
{
    // default constructor , the super allows us to change the name in the parent 
    // by calling the constructor of the animal class 
    // thus Wildcat is a animal 
    public Wildcat(){
        super("Kentucky the Wildcat", " Go Cats ");
    }

    public Wildcat(String Name , String Desc ) {
        super(Name, Desc); 
    }

    @Override
    public String eat(){
        return  "Wildcats munch on things like mice  " ;
    }

    @Override
    public String makeNoise() { 
        return " Waa-Waa-Waa " ; 
    }

    @Override
    public String walk(){
        return "on four legs "; 
    }
}

