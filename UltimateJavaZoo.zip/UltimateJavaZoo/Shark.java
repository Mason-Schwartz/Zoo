public class Shark extends Animal implements Swimming
{
    public Shark()
    {
        super("Frank the Shark", 
              "I'm the killer of the sea");
    }
    
    public Shark(String name, String desc) 
    {
        super(name, desc);
    }
    
    @Override
    public String eat()
    {
        return "The shark hunts a poor fishy.";
    }
    
    @Override
    public String makeNoise()
    {
        return "Blub blub fangs death";   
    }
   
    @Override
    public String swim()
    {
        return "The shark glides effortlessly through the water.";
    }
    
    @Override
    public String toString() {
        return this.getClass().getName() + " " + super.toString();
    }
}
