
public class YellowstoneWolf extends Wolf
{
    private String pack;

    public YellowstoneWolf() 
    {
        super("Alex the Yellowstone Wolf", "Wolf that live in Yellowstone Park");

        this.pack = "Lamar";
    }

    @Override
    public String eat()
    {
        return "The wolf hunts down a bison and has a large meal.";
    }
}
