public class Wolf extends Animal implements Walking
{
    public Wolf()
    {
        super("Wally the Wolf", "some kind of dog-like thing");
    }    

    public Wolf(String name, String desc)
    {
        super(name, desc);
    }   

    public String makeNoise()
    {
        return "Woof woof.";
    }

    public String eat()
    {
        return "The wolf eats a weak baby elk.";
    }

    public String walk()
    {
        return "Runs with the pack.";
    }
}