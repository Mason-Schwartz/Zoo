public class Seal extends Animal implements Walking, Swimming
{
    //Fields (nouns or adjective)
    private String flipper;
    
    //Constructor
    public Seal() {
        super("Broseph the Seal","I live in WP");
        this.flipper = "none";
    }
    public Seal(String name, String desc, String flipper) {
        super(name,desc);
        this.flipper = flipper;
    }
    
    public String getFlipper(){
        return this.flipper;
    }
    public void setFlipper(String flipper){
        this.flipper = flipper;
    }

    @Override
    public String eat() {
        return "I munch on little fish.";
    }
    
    @Override
    public String makeNoise() {
        return "Arf!";
    }
    
    @Override
    public String walk() {
        return "walks with difficulty";
    }
    
    @Override
    public String swim() {
        return "swims  with grace";
    }
    
    @Override
    public String smell() {
        return "The seal smells of blubber and salt water.";
    }
    
    @Override
    public String toString() {
        return this.getClass().getName() + " " + super.toString() + " - " + this.flipper  + " - " + this.swim()   + " - " + this.walk();
    } 
}






