
/*
 * This class extends Rhino, which in turn extends Animal
 * WhiteRhino will have access to protected (not private) instance variables 
 * and all public or protected methods from both Animal and Rhino
 */
/**
 * Class to represent a White Rhino
 * 
 * @author replace me at UCCS
 * @version 6/20/2018
 */
public class WhiteRhino extends Rhino
{
    public WhiteRhino() {
        // WhiteRhino can access name and description because it 
        // extends Rhino which extends Animal AND because name and
        // description have protected as their access modifier
        this.name = "Billy the White Rhino";
        this.description = "I am extinct";
    }
    
    @Override
    /* 
     * Override the makeNoise method of the Rhino class 
     * (which in turn overrode the makeNoise method of the Animal 
     * class)
     */
    public String makeNoise() {
        return "I snort like a pig";
    }
}
