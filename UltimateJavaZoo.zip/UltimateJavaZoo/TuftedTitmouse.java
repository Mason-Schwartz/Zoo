/**
 * Class to represent a Tufted Titmouse
 * 
 * @author Jon Haas at UCCS
 * @version 6/20/2018
 */
public class TuftedTitmouse extends Animal implements Walking, Swimming, Flying
{
    /**
     * Constructor for objects of class TuftedTitmouse
     */
    public TuftedTitmouse()
    {
        super("Reggie the Tufted Titmouse","I like to fly");
    }

    @Override 
    public String eat(){
        return "I like to eat nuts.";
    }

    @Override
    public String makeNoise(){
        return "I tweet";
    }

    @Override
    public String walk(){
        return "I am a speedy walker";
    }

    @Override
    public String swim(){
        return "I suck at swimming.";
    }

    @Override
    public String fly(){
        return "I fly like a rock.";
    }
}
