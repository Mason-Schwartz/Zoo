/**
 * Class to represent a Camel Dawg
 * 
 * @author Matt Stansberry at UCCS
 * @version 6/20/2018
 */
public class CamelDawg extends Animal implements Walking, Swimming
{    
    /**
     * Constructor for objects of class CamelDawg
     */
    public CamelDawg() 
    {
        super("Tyrone the Camel Dawg", "I am senstive and sweet");
    }

    @Override
    public String eat(){
        return "Munch Munch Munch.. i like soft leaves";
    }

    @Override
    public String makeNoise() {
        return "grunt grunt grunt";
    }

    @Override
    public String walk() {
        return "I run Fast";
    }

    @Override
    public String swim() {
        return "Me swim so so ... Ehhh kinda";
    }
    
    public String smell() {
        return "The camelDawg smells of a meadow and fresh cut grass.";
    }
}
