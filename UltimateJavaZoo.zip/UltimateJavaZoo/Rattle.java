
public class Rattle extends Snake
{
    private String pet;

    public Rattle()
    {
        super("Genie the rattlesnake",
            "He has lived for a while and lays in the sun");
    }

    @Override
    public String makeNoise()
    {
        return "rattles its tail";
    }
}