public abstract class WaterMammal extends Animal
{
    public WaterMammal(String name, String desc)
    {
        super(name, desc);
    }
    WaterMammal(){
        super("name", "this is a swimming mammal");
    }
}

