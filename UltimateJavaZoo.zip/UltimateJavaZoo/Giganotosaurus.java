
public class Giganotosaurus extends Animal implements Walking
{
    public Giganotosaurus(){
        super("Giganotosaurus", "Some big beast");
    }
    
    @Override
    public String makeNoise(){
        return "Roar very loudly";
    }
    
    @Override
    public String eat(){
        return "Giganotosaurus eats everything in its path";
    }
    
    @Override
    public String walk(){
        return "Giganotosaurus does a walk....";
    }
}
