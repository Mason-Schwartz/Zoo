
public class Penguin extends Animal implements Walking,Swimming
{
    public Penguin()
    {
        super("Happy the Penguin","A dancing bird");
        //super calls the constructor of the parent class
    }
    
    public Penguin(String name, String desc)
    {
        super(name, desc);
    }

    @Override
    public String eat()
    {
       return "The Penguin eats fish."; 
    }
    
    @Override
    public String makeNoise()
    {
        return "Honk";
    }
    
    
    @Override
    public String walk()
    {
     return "Walks Aukwardly";   
    }
    
    @Override
    public String swim()
    {
     return "Swims gracefully";   
    }
}
