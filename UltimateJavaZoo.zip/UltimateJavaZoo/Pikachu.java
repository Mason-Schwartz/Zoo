
public class Pikachu extends Animal implements Walking
{
    public Pikachu() {
        super("Pika! the Pikachu", "A rare pokemon and and ammbassador of friendship.");
    }

    public Pikachu(String name, String desc)
    {
        super(name, desc);
    }

    public String makeNoise() {
        return "PIK-A-CHU";
    }

    public String eat() {
        return "The pikachu eats up your mobile battery...";
    }

    public String walk() {
        return "The pikachu prances obliviously.";
    }
    
    public String smell() {
        return "The pikachu smells of fresh rain before a storm.";
    }
}