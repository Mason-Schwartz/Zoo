/**
 * Class to represent a Snow Leopard
 * 
 * @author Leilani Bierman at UCCS
 * @version 6/20/2018
 */
public class SnowLeopard extends Animal implements Walking, Swimming
{
    /**
     * Constructor for objects of class SnowLeopard
     */
    public SnowLeopard()
    {
        super("Mischa the Snow Leopard", "Watch out, I bite");  
    }

    @Override
    public String eat(){
        return "die critters";
    }

    @Override
    public String makeNoise(){
        return "chuff chuff";
    }

    @Override
    public String swim(){
        return "like a predator";
    };

    @Override
    public String walk(){
        return "stalks by";
    };
}
