
public class Falcon extends Animal implements Flying, Walking
{

    public Falcon() {
        super("Francessco the Falcon", "The most badass bird ever");
    }

    @Override
    public String eat() {
        return "Pecking noise";
    }

    @Override
    public String walk() {
        return "Bird Walk";
    }

    @Override
    public String fly() {
        return "Flapping Wings";
    }

    @Override
    public String makeNoise() {
        return "Cakaaa!";
    } 
}
