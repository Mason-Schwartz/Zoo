/**
 * Class to represent a Capybara
 * 
 * @author Daniel Lande at UCCS
 * @version 6/20/2018
 */
public class Capybara extends Animal implements Walking, Swimming
{
    /**
     * Constructor for objects of class Capybara
     */
    public Capybara() 
    {
        super("Jack the Capybara", "I like to swim and play in cool mountain streams.");
    }

    @Override
    public String eat() {
        return "munch munch munch... I like soft leaves";
    }

    @Override
    public String makeNoise() {
        return "grunt grunt grunt";
    }

    @Override
    public String walk() {
        return "he slowly plods along...";
    }

    @Override
    public String swim() {
        return "The capybara is a graceful and agile swimmer.";
    }
    
    @Override
    public String smell() {
        return "The capybara smells of the mountains.";
    }
}
