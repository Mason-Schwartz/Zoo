
/**
 * Abstract class for Animals.
 * 
 * An abtract class means that we will not be able
 * to instantiate Animal objects. It will basically
 * be serving as a template for other classes that 
 * extend Animal.
 * 
 * @name Daniel Lande
 * @version 6/20/2018
 */
public abstract class Animal
{
    /* 
     * Instance Variables or fields
     * These are equivalent names for the same thing
     * Protected means that these variables are accessible
     * by this class and anything that inherits (extends) this class
     */
    protected String name;
    protected String description;
    // This variable is static; it belongs to the Animal class
    public static int numAnimals = 0;

    /**
     * Default Constructor for objects of class Animal.
     */
    public Animal() {
        // Call the other constructor that takes one String parameter,
        // passing in none for the name
        // This is called constructor chaining when one constructor
        // calls another
        this("none");
    }

    /**
     * Constructor for objects of class Animal.
     * 
     * @param name The name of the animal in the format "Name the animal type", ie
     * "Joey the Bird".
     */
    public Animal(String name) {
        // Call the other constructor that takes two String paremeters,
        // passing in the value referenced by the name variable and 
        // none for the description
        this(name, "none");
    }

    /**
     * Constructor for objects of class Animal
     * 
     * @param name The name of the animal in the format "Name the animal type", ie
     * "Joey the Bird".
     * 
     * @param description Description of the animal.
     */
    public Animal(String name, String description) {
        // Set the name and description for the animal
        this.name = name;
        this.description = description;
        // Increment the numAnimals indicating that another
        // animal has been created
        numAnimals++;
    }

    /*
     * Methods
     * I usually list setters and getters followed by other methods
     */ 
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

    /* This annotation (basically Java metadata or data about data)
     * means that we are telling the compiler to check to make sure
     * a parent (super class) contains a toString() method
     */ 
    @Override 
    /**
     * Overrides the toString() method of the Object class.
     * Will print the name and the description of the Animal.
     * 
     */
    public String toString() {
        return this.name + ": " + this.description;
    }

    /*
     * Abstract methods do not have a body. They define that any
     * class that inherits (extends) from this class must override
     * this method i.e. if Rhino extends Animal, it must have an eat()
     * method
     */ 
    /**
     * Specifies how an animal eats. Must be overridden
     * by all classes that inherit from Animal.
     * 
     * @return A String indicating how an animal eats
     */
    public abstract String eat();

    /**
     * Specifies how an animal makes noise. Must be overridden
     * by all classes that inherit from Animal.
     * 
     * @return A String indicating how an animal makes noise
     */
    public abstract String makeNoise();
    
    /**
     * Specifies how an animal makes noise. Must be overridden
     * by all classes that inherit from Animal.
     * 
     * @return A String indicating how an animal makes noise
     */
    public abstract String smell();
}
