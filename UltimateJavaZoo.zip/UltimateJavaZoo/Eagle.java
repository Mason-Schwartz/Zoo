
public class Eagle extends Animal implements Flying
{
    //ad more functionality
    public Eagle()
    {
        //calling parent constructor
        super ("Eddie the Eagle", "A happy eagle from California");

    }

    public Eagle(String name, String desc)
    {
        super(name,desc);
    }

    @Override
    public String eat()
    {
        return "The Eagle  eats a worm";

    }

    @Override
    public String makeNoise()
    {
        return "CaaaCaaaa";
    }

    @Override
    public String fly()
    {
        return "soaring";
    }
}

