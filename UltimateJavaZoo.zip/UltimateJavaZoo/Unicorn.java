/**
 * Class to represent a Unicorn
 * 
 * @author Leilani Bierman at UCCS
 * @version 6/20/2018
 */
public class Unicorn extends Animal implements Flying, Swimming, Walking
{
    
    /**
     * Constructor for objects of class Unicorn
     */
    public Unicorn()
    {
        super("Kai the Unicorn", "I like water");
    }

    @Override
    public String eat(){
        return "Sprinkles 4 lyfe";
    }
    
    @Override
    public String makeNoise(){
        return "shiny shiny!";
    }
    
    @Override
    public String fly(){
        return "with sparkly wings";
    };
    @Override
    public String swim(){
        return "or rather walks on water";
    };
    @Override
    public String walk(){
        return "with a chiming sound";
    };
    
    @Override
    public String smell(){
        return "The unicorn smells of fruit and amazingness.";
    };
}
