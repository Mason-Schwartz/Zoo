
public class Cat extends Animal
{ 
    public Cat()    
    {
        super("Bo the Cat", "Is a feline");
    }

    public Cat (String name, String desc)
    {
        super (name, desc);
    }

    public String eat ()
    {
        return "Brought you a gift";
    }

    public String makeNoise ()
    {
        return ("Meow");
    }

    public String Walk () { 
        return "the cat visits through the garden.";
    }
}