public class Alligator extends Animal implements Swimming
{
    public Alligator()
    {
        super("Alli the Alligator", "not your average alligator");
    }
    
    public Alligator(String name, String desc)
    
    {
        super(name, desc);
    }

    public String makeNoise()
    {
        return "hiss";
    }
    
    public String eat()
    {
        return "the alligator eats surf and turf";
    }
    
    public String swim() 
    { 
        return "the alligator swims like a beast"; 
    }
}