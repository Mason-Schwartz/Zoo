
public class Duck extends Animal implements Walking, Flying, Swimming
{
    public Duck()
    {
       super("Reginald the duck", "a happy duck with beautiful black feathers");
    }
   
    public Duck(String name, String desc)
    {
       super(name, desc);
    }
   
    public String makeNoise()
    {
        return "quack";
    }
   
    public String eat()
    {
        return "the duck eats the bread you tossed to it";
    }
    
    public String walk()
    {
        return "the duck waddles around";
    }
    
    public String fly()
    {
        return "the duck flies toward your corndog";
    }
    
    public String swim()
    {
        return "the duck swims the 200m freestyle, 100m butterfly,and the 400m individual medley";
    }
}
