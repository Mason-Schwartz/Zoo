
/**
 * Creating a class called EvilScientist.  This will be my contribution to the Zoo
 *
 * @author Christopher Beyrouty at SDSU
 * @version July 12, 2017
 */
public class EvilScientist extends Animal implements Walking, Swimming //means we are inheriting characteristics from animal
{
    //Constructor - default
    public EvilScientist() //sets default values if nothing is sent
    {
        super("Dr. Dingleberry","A mad scientist who wants to rule the world.");   //"super gives access to the parent"   
    }

    //Constructor - asks for input on both
    public EvilScientist(String name, String desc)
    {
        super(name, desc);
    }

    @Override          //needs to be done here because in animal eat and makeNoise are abstract. forcing me to put in info.
    public String eat()
    {
        return "The evil Scientist doesn't eat, that's why he is so grumpy.";
    }  
    @Override
    public String makeNoise()
    {
        return "Mwahahaha";
    }
    @Override
    public String walk()
    {
        return "two legs-bipedal";
    }
    @Override
    public String swim()
    {
        return "can but hates to swim.";
    }
}
