/**
 * Class to represent a Haggis
 * 
 * @author Henry Szuster at UCCS
 * @version 6/20/2018
 */
public class Haggis extends Animal implements Walking, Swimming, Flying
{
    /**
     * Constructor for objects of class Haggis
     */
    public Haggis() 
    {
        super("Jamesy the Haggis", "Pure dead gallus.");    
    }

    @Override
    public String eat() {
        return "munch, munch munch";
    }

    @Override
    public String makeNoise() {
        return "grunt, grunt, grunt";
    }

    @Override
    public String walk() {
        return "walks like hoppity, hop";
    }

    @Override
    public String swim() {
        return "swims...like a brick";
    }

    @Override
    public String fly() {
        return "flies gliding high";
    }
}
