
public class Pegasus extends Animal implements Flying
{
    public Pegasus(){
        super("Polly the Pegasus", "A flying horse with wings... totally real...");
    }

    public String makeNoise(){
        return "Neigh! (with the sound of wind chimes in the background)";
    }

    public String eat(){
        return "Yummy, soylent rainbows...";
    }

    public String fly(){
        return "Flap, flap. (As colorful sparkles fall to the ground...)";
    }
    
    public String smell(){
        return "The Pegasus smells of ";
    }

    public Pegasus(String name, String description){
        super(name, description);
    }
}