
public class Orangutan extends Primate
{
    // instance variables
    private String age;

    /**
     * Constructor for objects of class Orangutan
     */
    public Orangutan()
    {
        super("Polly the Orangutan", "orange and sometimes mean");
        this.age = "pretty old";
    }

    @Override
    public String makeNoise()
    {
        return "hoots and makes a general din";
    }
}