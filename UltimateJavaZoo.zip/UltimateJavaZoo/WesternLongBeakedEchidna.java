
public class WesternLongBeakedEchidna extends Animal implements Walking
{
    public WesternLongBeakedEchidna(){
        super("Diego the Western Long-Beaked Echidna", "An egg laying mammal.  Looks silly.");
    }
    
    public WesternLongBeakedEchidna(String name, String description){
        super(name, description);
    }

    public String makeNoise(){
        return "Dig, dig, dig.";
    }

    public String eat(){
        return "A long tongue whips out and grabs some termites";
    }

    public String walk(){
        return "Waddles around awkwardly.";
    }
}