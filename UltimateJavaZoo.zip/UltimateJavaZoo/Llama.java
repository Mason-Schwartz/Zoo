/**
 * Class to represent a Llama
 * 
 * @author Carlos Morales at UCCS
 * @version 6/20/2018
 */
public class Llama extends Animal implements Walking
{
    /**
     * Constructor for objects of class Llama
     */
    public Llama() 
    {
        super("Johnny the Llama", "I have great long fur.");        
    }

    @Override
    public String eat() {
        return "Munch munch munch... I like soft leaves";
    }

    @Override
    public String makeNoise() {
        return "grunt grunt grunt";
    }

    public String walk() {
        return "The llama can walk and spit!";
    }
    
    public String smell() {
        return "Llama smells like wool.";
    }
}
