import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
/**
 * A wonderous and exciting Java zoo
 */
public class Zoo
{
    /*
     * Every Java program must have a main method if it will be able to run
     * This method throws an InterruptedException
     */
    public static void main(String[] args) throws InterruptedException 
    {
        List<Animal> animals = new ArrayList<Animal>();

        System.out.println("Welcome to the Zoo!\n");
        System.out.print("Building the cages");
        delayDots();
        System.out.print("Populating the animals");
        populateAnimals(animals);
        delayDots();
        System.out.print("Hiring zookeepers");
        delayDots();

        Scanner in = new Scanner(System.in);
        System.out.println("\nYou are standing in a wondrous zoo. What would you like to do?");
        System.out.println("Type help to find out what you can do.\n");
        String text = in.nextLine();
        String msg = "";
        while(!text.equals("leave"))
        {
            switch(text)
            {
                case "help" : 
                msg = "So far we can visit cages, listen, lunchtime, \n"+
                "look up, look around, smell, look down, leave, \n" +
                "and ask for help.";
                break;
                case "visit cages" : 
                msg = visitCages(animals);
                break;
                case "lunchtime" : 
                msg = lunchtime(animals);
                break;
                case "look up" :
                msg = lookUp(animals);
                break;
                case "look around" :
                msg = lookAround(animals);
                break;
                case "listen" :
                msg = listen(animals);
                break;
                case "look down":
                msg = lookDown(animals);
                break;
                case "smell":
                msg = smell(animals);
                break;
                default : msg = "You flail helplessly with indecision.";
            }
            System.out.println("\n" + msg);
            delayDots(2);
            System.out.println("\nYou are standing in a wondrous zoo. What would you like to do?\n");
            text = in.nextLine();
        }

        System.out.println(Math.random() < .8 ? "\nHave a nice day!  Hope you come back!" : "\nAn escaped lion eats you on your way out.  Sorry!");
    }

    public static String visitCages(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n       " + a.getDescription() + "\n";
        }
        return msg;
    }

    public static String lunchtime(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n       " 
            + a.eat() + "\n";
        }
        return msg;
    }

    public static String listen(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n       " 
            + a.makeNoise() + "\n";
        }
        return msg;
    }

    public static String lookDown(List<Animal> animals)
    {
        String msg = "";

        for(Animal a : animals)
        {
            if(a instanceof Swimming) 
            {
                Swimming f = (Swimming) a;
                msg +=a.getName() + ": \n       " 
                + f.swim() + "\n";
            }
        }
        return msg;

    }

    public static String lookAround(List<Animal> animals)
    {
        String msg = "";

        for(Animal a : animals)
        {
            if(a instanceof Walking) 
            {
                Walking w = (Walking) a;
                msg += a.getName() + ": \n       " 
                + w.walk() + "\n";
            }
        }
        return msg;
    }

    public static String lookUp(List<Animal> animals)
    {
        String msg = "";

        for(Animal a : animals)
        {
            if(a instanceof Flying) 
            {
                Flying f = (Flying) a;
                msg += a.getClass().getName() + ": " + a.getName() + ": \n       " 
                + f.fly() + "\n";
            }
        }
        return msg;
    }
    
    public static String smell(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n       " 
            + a.smell() + "\n";
        }
        return msg;
    }
    
    /**
     * This prints an ellipses with 1 second between each period
     * It then moves to the next line.
     */
    public static void delayDots(int dotAmount) throws InterruptedException 
    {
        for (int i=0; i<dotAmount; i++) {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(".");
        }
        System.out.println();
    }

    /**
     * This prints an ellipses with 1 second between each period
     * It then moves to the next line.
     */
    public static void delayDots() throws InterruptedException 
    {
        delayDots(0);
    }

    /**
     * This is where we will all collaborate.
     * Construct your animal and add it to the List
     * @param animals the list containing all the zoo animals
     */
    public static void populateAnimals(List<Animal> animals)
    {
        Basilisk a1 = new Basilisk();
        animals.add(a1);
        
        CamelDawg a2 = new CamelDawg();
        animals.add(a2);

        Capybara a3 = new Capybara();
        animals.add(a3);

        Haggis a4 = new Haggis();
        animals.add(a4);

        Hippogriff a5 = new Hippogriff();
        animals.add(a5);

        Kangaroo a6 = new Kangaroo();
        animals.add(a6);

        Llama a7 = new Llama();
        animals.add(a7);

        MonkSeal a8 = new MonkSeal();
        animals.add(a8);

        Rhino a9 = new Rhino();
        animals.add(a9);

        SnowLeopard a10 = new SnowLeopard();
        animals.add(a10);

        TuftedTitmouse a12 = new TuftedTitmouse();
        animals.add(a12);

        Unicorn a13 = new Unicorn();
        animals.add(a13);

        WhiteRhino a14 = new WhiteRhino();
        animals.add(a14);

        Bear a15 = new Bear();
        animals.add(a15);

        Pikachu a16 = new Pikachu();
        animals.add(a16);

        Whale a17 = new Whale();
        animals.add(a17);

        Bat a18 = new Bat();
        animals.add(a18);

        Vampire a19 = new Vampire();
        animals.add(a19);

        Fox a20 = new Fox();
        animals.add(a20);

        SilverFox a21 = new SilverFox();
        animals.add(a21);

        Unicorn a22 = new Unicorn();
        animals.add(a22);

        Snake a23 = new Snake();
        animals.add(a23);

        Cat a24 = new Cat();
        animals.add(a24);

        Giganotosaurus a25 = new Giganotosaurus();
        animals.add(a25);

        Salmon a26 = new Salmon();
        animals.add(a26);

        Wolf a27 = new Wolf();
        animals.add(a27);

        Duck a28 = new Duck();
        animals.add(a28);

        Pegasus a29 = new Pegasus();
        animals.add(a29);

        WesternLongBeakedEchidna a30 = new WesternLongBeakedEchidna();
        animals.add(a30);

        Alligator a31 = new Alligator();
        animals.add(a31);

        NinjaAlligator a32 = new NinjaAlligator();
        animals.add(a32);

        Primate a33 = new Primate();
        animals.add(a33);

        Orangutan a34 = new Orangutan();
        animals.add(a34);

        Seal a35 = new Seal();
        animals.add(a35);

        Badger a36 = new Badger();
        animals.add(a36);

        Whale a37 = new Whale();
        animals.add(a37);

        Eagle a38 = new Eagle();
        animals.add(a38);

        Dog a39 = new Dog();
        animals.add(a39);

        Ocelot a40 = new Ocelot();
        animals.add(a40);

        Penguin a41 = new Penguin();
        animals.add(a41);

        Platypus a42 = new Platypus();
        animals.add(a42);
        
        MalaysianAnt a43 = new MalaysianAnt();
        animals.add(a43);
        
        Shark a44 = new Shark();
        animals.add(a44);
        
        GiantSquid a45 = new GiantSquid();
        animals.add(a45);
        
        Seal a46 = new Seal();
        animals.add(a46);
        
        Dog a47 = new Dog();
        animals.add(a47);
        
        Falcon a48 = new Falcon();
        animals.add(a48);
        
        NylanderiaFulva a49 = new NylanderiaFulva();
        animals.add(a49);
        
        Falcon a50 = new Falcon();
        animals.add(a50);
        
        Wildcat a51 = new Wildcat();
        animals.add(a51);
        
        Tiger a52 = new Tiger();
        animals.add(a52);
        
        Dragon a53 = new Dragon();
        animals.add(a53);
        
        Hummingbird a54 = new Hummingbird();
        animals.add(a54);
        
        SeaSponge a55 = new SeaSponge();
        animals.add(a55);
        
        Buzzwole a56 = new Buzzwole();
        animals.add(a56);
        
        EvilScientist a57 = new EvilScientist();
        animals.add(a57);
        
        Gator a58 = new Gator();
        animals.add(a58);
        
        RichDuck a59 = new RichDuck();
        animals.add(a59);
       
        Rattle a60 = new Rattle();
        animals.add(a60);
        
        Snake a61 = new Snake();
        animals.add(a61);
        
        PPikachu a62 = new PPikachu();
        animals.add(a62);
        
        YellowstoneWolf a63 = new YellowstoneWolf();
        animals.add(a63);
        
        SovietCircusBear a64 = new SovietCircusBear();
        animals.add(a64);
        
        Horse a65 = new Horse();
        animals.add(a65);
        
        Phoneix a66 =new Phoneix();
        animals.add(a66);
    }
}