/**
 * Class to represent a Hippogriff
 * 
 * @author Taylor Badeau at UCCS
 * @version 6/20/2018
 */
public class Hippogriff extends Animal implements Walking, Flying, Swimming
{
    /**
     * Constructor for objects of class Hippogriff
     */
    public Hippogriff() 
    {
        super("Buckbeak", "I like to fly and save Harry and his stupid friends!!");
    }

    @Override
    public String eat() {
        return "yum yum....I like to eat ferrets and rats";
    }

    @Override
    public String makeNoise() {
        return "cuh kawwwwww!!!!!";
    }

    @Override
    public String fly() {
        return "I use my wings to gallantly fly";
    }

    @Override
    public String walk() {
        return "I trot along on my hooves...but I'd rather fly";
    }

    @Override
    public String swim() {
        return "I like to swim in the lake by Hogwarts";
    }
    
    public String smell() {
        return "The hippogriff smells like ferrets and rats and plague.";
    }
}

