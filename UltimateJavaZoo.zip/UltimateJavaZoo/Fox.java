
public class Fox extends Animal implements Walking
{
    public Fox()
    {
        super("Rodrigo the Fox","Caution: sly");
    }

    public Fox(String name, String desc)
    {
        super(name, desc);
    }

    public String makeNoise()
    {
        return "hatcha hatcha hatcha hatcha hooo! Hu hu hu hu hu hu hu hu huh!";
    }

    public String eat()
    {
        return "Chicken Licken";
    }

    public String walk()
    {
        return "the fox slinks from misdeed to misdeed";
    }
}