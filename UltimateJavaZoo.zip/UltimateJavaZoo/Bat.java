
public class Bat extends Animal implements Flying
{
    public Bat() 
    {
        super("Benny the Bat", "sleeps in dark places");
    }

    public Bat(String name, String desc)
    {
        super(name, desc);
    }

    public String makeNoise()
    {
        return "squeeeeeek";
    }

    public String eat() 
    {
        return "the bat eats insects";
    }

    public String fly()
    {
        return "A bat flies with leatherly wings, and has no feathers.";
    }
    
    public String smell() {
        return "The bat smells of freshly cut leather.";
    }
}