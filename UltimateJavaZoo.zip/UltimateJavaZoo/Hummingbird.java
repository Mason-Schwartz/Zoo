
/**
 * New child of the animal abstract class
 */
public class Hummingbird extends Animal implements Flying, Walking
{
    public Hummingbird()
    {
        super("Flit the Humingbird", "Flies like a maniac");
    }
    
    public Hummingbird(String name, String desc)
    {
        super(name, desc);
    }
    
    @Override
    public String eat()
    {
       return "I eat nector. If you don't have flowers, give me sugar water please!";
    }
    
    @Override
    public String makeNoise()
    {
        return "Chirpity Chirp Chirp";
    }
    
    @Override
    public String fly()
    {
        return "I swoop and dart. You can't catch me!";
    }
    
    @Override
    public String walk()
    {
        return "I step and hop into my nest";
    }
}
