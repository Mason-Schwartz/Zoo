public interface Smelling
{
    public String smell();
}