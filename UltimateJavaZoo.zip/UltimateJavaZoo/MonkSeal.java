/**
 * Class to represent a Monk Seal
 * 
 * @author Leilani Bierman at UCCS
 * @version 6/20/2018
 */
public class MonkSeal extends Animal implements Walking, Swimming
{
    /**
     * Constructor for objects of class MonkSeal
     */
    public MonkSeal()
    {
        super("Kai the Monk Seal", "I like water");
    }

    @Override
    public String eat(){
        return "here fishy, fishy, fishy";
    }

    @Override
    public String makeNoise(){
        return "orr orr orr";
    }

    @Override
    public String walk(){
        return "can you even call that walking?";
    };

    @Override
    public String swim(){
        return "like a ...seal";
    };
}
