public class MalaysianAnt extends Animal implements Walking, Flying {
    public MalaysianAnt() {
        super("Malaysian Ant", "An ant that explodes when it's in danger");
    }
    
    @Override
    public String eat() {
        return "I like to eat grass, and other small greens";
    }
    
    @Override
    public String makeNoise() {
        return "...";
    }
    
    @Override
    public String walk() {
        return "I scuttle around with my little stick legs";
    }
    
    @Override
    public String fly() {
        return "I can't acually fly, but when I blow myself up, boy do my limbs fly";
    }
    
    @Override
    public String smell() {
        return "The Malaysian Ant smells of nothingness.";
    }
}
