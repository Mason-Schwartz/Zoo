// using extends allows Dragon to inherit from the Animal class
// making this my walking animal
public class Dragon extends Animal implements Walking, Swimming 
{
    public Dragon()
    {
        // using super allows to call the parent constructor, if only used this.name = "Johnny, it would not work
        super("Joy the Dragon", " a friendly dragon from Mayberry");

    }

    public Dragon(String name, String desc)
    {
        super(name, desc);
    }

    @Override
    public String eat()
    {
        return "The Dragon eats a baby Eagle.";
    }

    @Override
    public String makeNoise()
    {
        return "Screech";
    }

    @Override
    public String walk()
    {
        return "With a silent slithering, the Dragon glides through the forest";
    }

    @Override
    public String swim()
    {
        return "With a silent slithering, the Dragon glides through the forest";
    }
}
