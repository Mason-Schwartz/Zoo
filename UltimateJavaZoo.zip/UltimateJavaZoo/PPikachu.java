
public class PPikachu extends Pikachu
{
    public PPikachu()
    {
        super("Paul the Pikachu","Flashes his lightning in every direction");
    }

    @Override
    public String makeNoise()
    {
        return "Oh yeah!!!";
    }

    @Override
    public String eat()
    {
        return "I'm hungry...";
    }

    @Override
    public String walk() {
        return "Paul prances.";
    }
    
    @Override
    public String smell()
    {
        return "Smells of rain before a storm.";
    }
}