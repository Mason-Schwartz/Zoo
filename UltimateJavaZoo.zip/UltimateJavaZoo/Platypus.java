
/**
 * Creating a class called platypus.  This will be my contribution to the Zoo
 *
 * @author Christopher Beyrouty at SDSU
 * @version July 12, 2017
 */
public class Platypus extends Animal implements Swimming//means we are inheriting characteristics from animal
{
    //Constructor - default
    public Platypus() //sets default values if nothing is sent
    {
        super("Perry the Platypus","A secret agent and friend of Phenius & Ferb");   //"super gives access to the parent"   
    }

    //Constructor - asks for input on both
    public Platypus(String name, String desc)
    {
        super(name, desc);
    }

    @Override          //needs to be done here because in animal eat and makeNoise are abstract. forcing me to put in info.
    public String eat()
    {
        return "The platypus eats icecream";
    }  

    @Override
    public String makeNoise()
    {
        return "The platypus makes a chattering noise when aggitated";
    }

    @Override
    public String swim()
    {
        return "The platypus swimms with his tail";
    }
}
