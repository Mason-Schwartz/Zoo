public class Salmon extends Animal implements Swimming
{
    public Salmon ()
    {
        super ("Sally the Salmon", "Swims in Alaskan waters");
    }

    public Salmon (String name, String desc)
    {
        super (name, desc);
    }

    public String eat ()
    {
        return "Eats insects.";
    }

    public String makeNoise ()
    {
        return "Gurgle, gurgle, gurgle...";
    }

    public String swim (){ 
        return "swimming upstream through cold waters.";
    }
}
